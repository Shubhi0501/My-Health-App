package com.application.healthapp.healthily;

public interface StepListener {

    public void step(long timeNs);

}